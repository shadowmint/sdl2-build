
Windows CE is no longer supported by SDL.

We have left the CE support in SDL 1.2 for those that must have it, and we
will accept patches that support more modern Windows Mobile platforms for
SDL 2.0.

--ryan.


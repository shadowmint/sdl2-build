var searchData=
[
  ['options',['options',['../struct_s_d_l_visual_test___s_u_t_config.html#afda1bef370f3d5ea6919b7b6a73d01c0',1,'SDLVisualTest_SUTConfig']]],
  ['output_5fdir',['output_dir',['../struct_s_d_l_visual_test___harness_state.html#aafa9a2fb15490380b6c2edd704f4fcf0',1,'SDLVisualTest_HarnessState']]]
];

var searchData=
[
  ['sdl_5faction_5fkill',['SDL_ACTION_KILL',['../_s_d_l__visualtest__action__configparser_8h.html#a383e41b8547eab149a0a4af867b3ebc6a87880c4f665344d4c3e12f9aa3af7410',1,'SDL_visualtest_action_configparser.h']]],
  ['sdl_5faction_5flaunch',['SDL_ACTION_LAUNCH',['../_s_d_l__visualtest__action__configparser_8h.html#a383e41b8547eab149a0a4af867b3ebc6ac5344bca6af9c07c4ee69ee4c2b18df2',1,'SDL_visualtest_action_configparser.h']]],
  ['sdl_5faction_5fquit',['SDL_ACTION_QUIT',['../_s_d_l__visualtest__action__configparser_8h.html#a383e41b8547eab149a0a4af867b3ebc6ad3d17a830b7e1e46e37d916130d8802a',1,'SDL_visualtest_action_configparser.h']]],
  ['sdl_5faction_5fscreenshot',['SDL_ACTION_SCREENSHOT',['../_s_d_l__visualtest__action__configparser_8h.html#a383e41b8547eab149a0a4af867b3ebc6af9b5d42cb90bf843f298be4593992fdb',1,'SDL_visualtest_action_configparser.h']]],
  ['sdl_5faction_5fverify',['SDL_ACTION_VERIFY',['../_s_d_l__visualtest__action__configparser_8h.html#a383e41b8547eab149a0a4af867b3ebc6a0853f8be8363015b822658b9f3b013f4',1,'SDL_visualtest_action_configparser.h']]]
];

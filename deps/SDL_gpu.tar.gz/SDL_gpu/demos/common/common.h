#ifndef _COMMON_H__
#define _COMMON_H__

void printRenderers(void);
void printCurrentRenderer(void);


#endif

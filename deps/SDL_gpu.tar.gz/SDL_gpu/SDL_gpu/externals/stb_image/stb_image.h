#ifndef STBI_INCLUDE_STB_IMAGE_H_WRAPPER
#define STBI_INCLUDE_STB_IMAGE_H_WRAPPER

#define STBI_HEADER_FILE_ONLY
#include "stb_image.c"

#endif
